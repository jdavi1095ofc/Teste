// Pyromaniac - plugin BepInEx para Classic Us, usando ClassicUs.ManuAPI 1.5.3.
// VERSAO 0.1: ainda nao compilada nem testada. Pontos marcados [VERIFICAR].
using System;
using System.Collections.Generic;
using System.Reflection;
using BepInEx;
using BepInEx.Unity.IL2CPP;
using HarmonyLib;
using UnityEngine;
using ClassicUs.ManuAPI;

namespace PyromaniacMod
{
    [BepInPlugin("com.pyromaniac.classicus", "Pyromaniac", "0.1.0")]
    [BepInDependency("classicus.manuapi")]
    public class PyromaniacPlugin : BasePlugin
    {
        public override void Load()
        {
            // Papel (virtual: nao precisa de classe IL2CPP propria)
            RoleRegistry.RegisterVirtual(new PyromaniacRole());

            // Menu de configuracoes do lobby
            SettingsMenuAPI.Register(4, b =>
            {
                b.AddToggle("PyroVent", "Pyromaniac: pode usar dutos",
                    () => PyroConfig.CanVent, v => PyroConfig.CanVent = v);
                b.AddNumeric("PyroChance", "Pyromaniac: chance de aparecer (%)", 1f, 1f, 100f, "0",
                    () => PyroConfig.Chance, v => PyroConfig.Chance = v);
                b.AddNumeric("PyroSoakCd", "Tempo de recarga do Soak (s)", 1f, 0f, 15f, "0",
                    () => PyroConfig.SoakCooldown, v => PyroConfig.SoakCooldown = v);
                b.AddNumeric("PyroBurnCd", "Tempo de recarga do Burn (s)", 1f, 0f, 60f, "0",
                    () => PyroConfig.BurnCooldown, v => PyroConfig.BurnCooldown = v);
            });

            // Botoes (o construtor do CustomAbility deve registra-los)  [VERIFICAR]
            PyroState.Soak = new SoakAbility();
            PyroState.Burn = new BurnAbility();

            // Limpa o fogo ao comecar partida e ao entrar em reuniao
            GameEvents.GameStarted += _ => PyroState.ClearFlames();
            GameEvents.AtMeeting += _ => PyroState.ClearFlames();

            new Harmony("com.pyromaniac.classicus").PatchAll();
            Log.LogInfo("Pyromaniac carregado.");
        }
    }

    // ---------------- Configuracao (valores padrao) ----------------
    public static class PyroConfig
    {
        public static bool CanVent = true;
        public static float Chance = 50f;        // 1..100
        public static float SoakCooldown = 10f;  // 0..15
        public static float BurnCooldown = 30f;  // 0..60
    }

    // ---------------- Estado do fogo (local) ----------------
    public static class PyroState
    {
        public const string RoleName = "Pyromaniac";
        public const float FlameSeconds = 15f;
        public static SoakAbility Soak;
        public static BurnAbility Burn;

        // PlayerId -> momento em que o fogo some
        public static readonly Dictionary<byte, float> Flames = new Dictionary<byte, float>();

        public static void ClearFlames() { Flames.Clear(); }

        public static bool LocalIsPyromaniac()
        {
            var me = PlayerControl.LocalPlayer;
            if (me == null || me.Data == null || me.Data.IsDead) return false;
            return RoleRegistry.IsAssigned(me, RoleName);
        }

        public static bool LocalIsImpostor()
        {
            var me = PlayerControl.LocalPlayer;
            return me != null && me.Data != null && me.Data.myRole != null && me.Data.myRole.RoleTeamType == RoleTeamTypes.Impostor;
        }

        public static void AddFlame(PlayerControl target)
        {
            Flames[target.PlayerId] = Time.time + FlameSeconds;
            // TODO rede: avisar os outros impostores (Manactor RPC). Hoje so o Pyromaniac ve.
        }

        public static void Prune()
        {
            if (Flames.Count == 0) return;
            var remove = new List<byte>();
            foreach (var kv in Flames) if (Time.time >= kv.Value) remove.Add(kv.Key);
            foreach (var id in remove) Flames.Remove(id);
        }
    }

    // ---------------- Papel ----------------
    public class PyromaniacRole : CustomImpostorRole
    {
        public override string DisplayName => "Pyromaniac";
        public override string RoleTypeName => PyroState.RoleName;
        public override string Description => "Burn the all crew.";
        public override string DescriptionShort => "Soak and burn.";
        public override Color TeamColor => Color.red;
        public override bool CanVent => PyroConfig.CanVent;
        public override bool CanSabotage => true;
        public override bool CanUseKillButton => false;        // sem botao de matar
        public override int Count => 1;
        public override float RoleChancePercent => PyroConfig.Chance;
        public override string KillAbilityName => "Soak";
        public override string KillAbilityImageName => "Soak";
    }

    // ---------------- Botao Soak ----------------
    public class SoakAbility : CustomAbility
    {
        static readonly LoadableSprite Icon = new LoadableSprite(
            Assembly.GetExecutingAssembly(), "soak.png", 100f, true);

        protected override string Name => "Soak";
        protected override float Cooldown => PyroConfig.SoakCooldown;
        protected override AspectPosition.EdgeAlignments Alignment => AspectPosition.EdgeAlignments.RightBottom;
        protected override Vector3 DistanceFromEdge => AbilityButtonGrid.SlotA;
        protected override Sprite CreateIcon(Sprite original) => Icon.Get();
        protected override bool IsVisible() => PyroState.LocalIsPyromaniac();
        protected override bool CanActivate()
        {
            if (!PyroState.LocalIsPyromaniac()) return false;
            var t = PlayerControl.LocalPlayer.FindClosestTarget();            // [VERIFICAR assinatura]
            return t != null && !t.Data.IsDead;
        }
        protected override void OnActivate()
        {
            var t = PlayerControl.LocalPlayer.FindClosestTarget();
            if (t == null) return;
            PyroState.AddFlame(t);
            StartCooldown(Cooldown);
        }
    }

    // ---------------- Botao Burn ----------------
    public class BurnAbility : CustomAbility
    {
        static readonly LoadableSprite Icon = new LoadableSprite(
            Assembly.GetExecutingAssembly(), "burn.png", 100f, true);

        protected override string Name => "Burn";
        protected override float Cooldown => PyroConfig.BurnCooldown;
        protected override AspectPosition.EdgeAlignments Alignment => AspectPosition.EdgeAlignments.RightBottom;
        protected override Vector3 DistanceFromEdge => AbilityButtonGrid.SlotB;
        protected override Sprite CreateIcon(Sprite original) => Icon.Get();
        protected override bool IsVisible() => PyroState.LocalIsPyromaniac();
        protected override bool CanActivate() { PyroState.Prune(); return PyroState.LocalIsPyromaniac() && PyroState.Flames.Count > 0; }
        protected override void OnActivate()
        {
            PyroState.Prune();
            var me = PlayerControl.LocalPlayer;
            foreach (var p in PlayerControl.AllPlayerControls)                 // [VERIFICAR tipo da lista]
            {
                if (p == null || p.Data == null || p.Data.IsDead) continue;
                if (!PyroState.Flames.ContainsKey(p.PlayerId)) continue;
                var req = new KillRequest
                {
                    TeleportKiller = false,
                    CreateDeadBody = true,
                    PlayKillSound = true,
                    ShowKillAnimation = false,
                    ResultFlags = MurderResultFlags.Succeeded
                };
                KillManager.Kill(me, p, req);
            }
            PyroState.ClearFlames();
            StartCooldown(Cooldown);
        }
    }

    // ---------------- Fogo ao lado do nome ----------------
    [HarmonyPatch(typeof(PlayerControl), "FixedUpdate")]
    public static class NameFlamePatch
    {
        const string Mark = " <color=#FF6A00>[FOGO]</color>";   // troque por emoji se a fonte suportar

        public static void Postfix(PlayerControl __instance)
        {
            if (__instance == null || __instance.nameText == null) return;
            PyroState.Prune();
            string t = __instance.nameText.text;
            int i = t.IndexOf(Mark, StringComparison.Ordinal);
            if (i >= 0) t = t.Remove(i, Mark.Length);
            bool burning = PyroState.Flames.ContainsKey(__instance.PlayerId) && PyroState.LocalIsImpostor();
            __instance.nameText.text = burning ? t + Mark : t;
        }
    }
}
